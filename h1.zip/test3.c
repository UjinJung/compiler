int main(void){
    char _name;
    double na;
    int _;
    int _01234567890123456789;
    int i;
/*
Hello Lex!!
*/
    if(!na){
        for(i = 0; i < 20; i++)
            printf("Hel\"lo\n");
        +01234567890123456789;
        _name = "String"; //String!!!!!
    }else{
        i = 0;
        while(i < 20){
            i++;
        }
    }
    return;
}
