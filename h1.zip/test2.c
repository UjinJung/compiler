int main(void){
    char _name;
    double na;
    int _01234567890123456789;
    int i;


/*
Hello Lex!!
*/
    if(!na){
        for(i = 0; i < 20; i++)
            printf("Hell\"o\n");
        +1234567890123456789;
        _name = "String";  //String!!!!!
    }else{
        i = 0;
        while(i < 20){
            i++;
        }
    }
    return;
}
