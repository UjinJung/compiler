char str[20] = "computer";
 int i;
 for( i = 0; i <= 5; i++)
    printf("%c\"", str[i]);

if (i ==0)
    printf("Hello!!!");

printf("%s", str);
 return 0;
